# Servidor mínimo Flask -> npm/pip: pip install flask flask-cors psycopg2-binary python-dotenv
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import base64
import datetime
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'Base de datos'))
import bd
from db_conn import get_connection

app = Flask(__name__)
CORS(app)

def foto_bytea_to_dataurl(bytea):
	"""Convierte bytea (bytes) a data URL base64 para uso en img src."""
	if not bytea:
		return None
	try:
		b64 = base64.b64encode(bytea).decode('utf-8')
		# Asumir png si no hay info; clientes pueden renderizar igualmente
		return f"data:image/png;base64,{b64}"
	except Exception:
		return None

def dataurl_to_bytea(dataurl):
	"""Convierte data URL (data:image/xxx;base64,...) a bytes para insertar en bytea."""
	if not dataurl:
		return None
	if ',' in dataurl:
		_, b64 = dataurl.split(',', 1)
	else:
		b64 = dataurl
	try:
		return base64.b64decode(b64)
	except Exception:
		return None

def permitir_historial_reabastecer(cur):
	"""Permite guardar varios reabastecimientos para un mismo producto."""
	cur.execute(
		"""
		DO $$
		DECLARE
			constraint_name text;
		BEGIN
			SELECT c.conname INTO constraint_name
			FROM pg_constraint c
			JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
			WHERE c.conrelid = 'tmreabastecer'::regclass
				AND c.contype = 'u'
				AND a.attname = 'fkcodigo'
			LIMIT 1;

			IF constraint_name IS NOT NULL THEN
				EXECUTE format('ALTER TABLE tmreabastecer DROP CONSTRAINT %I', constraint_name);
			END IF;
		END $$;
		"""
	)

@app.route('/api/ping', methods=['GET'])
def ping():
	try:
		now = bd.fetchall('SELECT NOW() as now')
		return jsonify({'ok': True, 'serverTime': now[0]['now']})
	except Exception as e:
		return jsonify({'ok': False, 'error': str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
	data = request.get_json() or {}
	username = data.get('usuario')
	password = data.get('password')
	if not username or not password:
		return jsonify({'success': False, 'message': 'Usuario y contraseña requeridos'}), 400
	try:
		# Tabla real: tmusuarios(pkusuario, contra)
		q = 'SELECT pkusuario, contra FROM tmusuarios WHERE pkusuario = %s LIMIT 1'
		rows = bd.fetchall(q, (username,))
		if not rows:
			return jsonify({'success': False, 'message': 'Usuario no encontrado'}), 401
		user = rows[0]
		# Comparación en texto plano (según tu script). En producción usar hashing.
		if user['contra'] == password:
			return jsonify({'success': True, 'usuario': user['pkusuario']})
		else:
			return jsonify({'success': False, 'message': 'Contraseña incorrecta'}), 401
	except Exception as e:
		return jsonify({'success': False, 'message': 'Error del servidor', 'error': str(e)}), 500

@app.route('/api/inventory', methods=['GET'])
def get_inventory():
	try:
		q = """
		SELECT
			i.pkcodigo::text AS id,
			i.pkcodigo::text AS codigo,
			i.categoria,
			i.nombre,
			i.precio_unitario::numeric AS precio_unitario,
			i.fecha_vencimiento AS fecha_venc,
			i.notas,
			i.restantes::integer AS cantidad_actual,
			r.fecha_adquisicion AS fecha_adq,
			r.proveedor,
			r.comprobado_por,
			COALESCE(r.costo_total, i.precio_unitario * i.restantes)::numeric AS costo_total,
			to_char(now()::date, 'DD/MM/YYYY') AS ultima_actualizacion
		FROM tdnventario i
		LEFT JOIN LATERAL (
			SELECT fecha_adquisicion, proveedor, comprobado_por, costo_total
			FROM tmreabastecer
			WHERE fkcodigo = i.pkcodigo
			ORDER BY num DESC
			LIMIT 1
		) r ON true;
		"""
		rows = bd.fetchall(q)
		result = []
		for r in rows:
			result.append({
				'id': r.get('id'),
				'codigo': str(r.get('codigo') or ''),
				'nombre': r.get('nombre') or '',
				'precio_venta': float(r.get('precio_unitario') or 0),
				'imagen': 'https://via.placeholder.com/60',
				'cantidad_actual': int(r.get('cantidad_actual') or 0),
				'fecha_adq': r.get('fecha_adq') or 'N/A',
				'fecha_venc': r.get('fecha_venc') or 'No aplica',
				'proveedor': r.get('proveedor') or '',
				'costo_unit': float(r.get('precio_unitario') or 0),
				'costo_total': float(r.get('costo_total') or 0),
				'ultima_actualizacion': r.get('ultima_actualizacion') or '',
				'notas': r.get('notas') or ''
			})
		return jsonify(result)
	except Exception as e:
		return jsonify({'error': str(e)}), 500

@app.route('/api/product', methods=['POST'])
def save_product():
	data = request.get_json() or {}
	codigo = data.get('codigo')
	nombre = data.get('nombre')
	categoria = data.get('categoria') or 'otros'
	precio_unit = data.get('precioUnitario') or data.get('precio_unitario') or 0
	cantidad = data.get('cantidad') or 0
	proveedor = data.get('proveedor') or ''
	fecha_adq = data.get('fechaAdquisicion') or data.get('fecha_adquisicion') or ''
	if not fecha_adq:
		fecha_adq = datetime.date.today().isoformat()
	fecha_venc = data.get('fechaVencimiento') or data.get('fecha_vencimiento') or 'No aplica'
	if not fecha_venc:
		fecha_venc = 'No aplica'
	comprobado_por = data.get('comprobadoPor') or data.get('comprobado_por') or ''
	notas = data.get('notas') or ''

	if not codigo or not nombre:
		return jsonify({'success': False, 'message': 'Faltan campos obligatorios'}), 400

	try:
		precio_num = float(precio_unit or 0)
		cantidad_num = int(cantidad or 0)
		costo_total = float(data.get('costoTotal') or (precio_num * cantidad_num))

		q1 = """
		INSERT INTO tdnventario(pkcodigo, categoria, nombre, fecha_vencimiento, notas, precio_unitario, restantes, fkid)
		VALUES (%s, %s, %s, %s, %s, %s, %s, 1)
		ON CONFLICT (pkcodigo) DO UPDATE SET
			categoria = EXCLUDED.categoria,
			nombre = EXCLUDED.nombre,
			fecha_vencimiento = EXCLUDED.fecha_vencimiento,
			notas = EXCLUDED.notas,
			precio_unitario = EXCLUDED.precio_unitario,
			restantes = tdnventario.restantes + EXCLUDED.restantes;
		"""
		affected1 = bd.execute(q1, (codigo, categoria, nombre, fecha_venc, notas, precio_num, cantidad_num))

		with get_connection() as conn:
			with conn.cursor() as cur:
				permitir_historial_reabastecer(cur)
				cur.execute(
					"""
					INSERT INTO tmreabastecer(fkcodigo, fecha_adquisicion, comprobado_por, proveedor, cantidad, costo_total, fkid)
					VALUES (%s, %s, %s, %s, %s, %s, 1)
					""",
					(codigo, fecha_adq, comprobado_por, proveedor, cantidad_num, costo_total)
				)
				affected2 = cur.rowcount
			conn.commit()

		return jsonify({'success': True, 'affected_inventory': affected1, 'affected_reabastecer': affected2})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/product/<codigo>', methods=['GET'])
def get_product(codigo):
	try:
		q = """
		SELECT
			i.pkcodigo AS id,
			i.pkcodigo AS codigo,
			i.categoria,
			i.nombre,
			i.fecha_vencimiento AS fecha_vencimiento,
			i.notas,
			i.precio_unitario::numeric AS precio_unitario,
			i.restantes::integer AS restantes,
			r.fecha_adquisicion,
			r.comprobado_por,
			r.proveedor,
			r.cantidad::integer AS cantidad,
			r.costo_total::numeric AS costo_total
		FROM tdnventario i
		LEFT JOIN LATERAL (
			SELECT fecha_adquisicion, comprobado_por, proveedor, cantidad, costo_total
			FROM tmreabastecer
			WHERE fkcodigo = i.pkcodigo
			ORDER BY num DESC
			LIMIT 1
		) r ON true
		WHERE i.pkcodigo = %s
		LIMIT 1
		"""
		rows = bd.fetchall(q, (codigo,))
		if not rows:
			return jsonify({'success': False, 'message': 'Producto no encontrado'}), 404
		row = rows[0]
		return jsonify({
			'success': True,
			'producto': {
				'id': row['id'],
				'codigo': row['codigo'],
				'categoria': row['categoria'],
				'nombre': row['nombre'],
				'fecha_vencimiento': row['fecha_vencimiento'],
				'notas': row['notas'],
				'precio_unitario': float(row['precio_unitario'] or 0),
				'restantes': int(row['restantes'] or 0),
				'fecha_adquisicion': row['fecha_adquisicion'] or '',
				'comprobado_por': row['comprobado_por'] or '',
				'proveedor': row['proveedor'] or '',
				'cantidad': int(row['cantidad'] or 0),
				'costo_total': float(row['costo_total'] or 0)
			}
		})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/product/<codigo>', methods=['PUT'])
def update_product(codigo):
	data = request.get_json() or {}
	nombre = data.get('nombre')
	categoria = data.get('categoria') or 'otros'
	precio_unit = data.get('precioUnitario') or data.get('precio_unitario') or 0
	cantidad = data.get('cantidad') or data.get('restantes') or 0
	proveedor = data.get('proveedor') or ''
	fecha_adq = data.get('fechaAdquisicion') or data.get('fecha_adquisicion') or ''
	fecha_venc = data.get('fechaVencimiento') or data.get('fecha_vencimiento') or 'No aplica'
	comprobado_por = data.get('comprobadoPor') or data.get('comprobado_por') or ''
	notas = data.get('notas') or ''
	if not fecha_adq:
		fecha_adq = datetime.date.today().isoformat()
	if not fecha_venc:
		fecha_venc = 'No aplica'

	try:
		precio_num = float(precio_unit or 0)
		cantidad_num = int(cantidad or 0)
		costo_total = float(data.get('costoTotal') or (precio_num * cantidad_num))

		with get_connection() as conn:
			with conn.cursor() as cur:
				cur.execute(
					"""
					UPDATE tdnventario
					SET categoria = %s,
						nombre = %s,
						fecha_vencimiento = %s,
						notas = %s,
						precio_unitario = %s,
						restantes = %s
					WHERE pkcodigo = %s
					""",
					(categoria, nombre, fecha_venc, notas, precio_num, cantidad_num, codigo)
				)
				cur.execute("SELECT num FROM tmreabastecer WHERE fkcodigo = %s ORDER BY num DESC LIMIT 1", (codigo,))
				reabastecimiento = cur.fetchone()
				if reabastecimiento:
					cur.execute(
						"""
						UPDATE tmreabastecer
						SET fecha_adquisicion = %s,
							comprobado_por = %s,
							proveedor = %s,
							cantidad = %s,
							costo_total = %s
						WHERE num = %s
						""",
						(fecha_adq, comprobado_por, proveedor, cantidad_num, costo_total, reabastecimiento[0])
					)
				else:
					cur.execute(
						"""
						INSERT INTO tmreabastecer(fkcodigo, fecha_adquisicion, comprobado_por, proveedor, cantidad, costo_total, fkid)
						VALUES (%s, %s, %s, %s, %s, %s, 1)
						""",
						(codigo, fecha_adq, comprobado_por, proveedor, cantidad_num, costo_total)
					)
			conn.commit()

		return jsonify({'success': True, 'message': 'Producto actualizado correctamente'})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/product/<codigo>', methods=['DELETE'])
def delete_product(codigo):
	try:
		with get_connection() as conn:
			with conn.cursor() as cur:
				cur.execute("DELETE FROM tmreabastecer WHERE fkcodigo = %s", (codigo,))
				cur.execute("DELETE FROM tdnventario WHERE pkcodigo = %s", (codigo,))
				if cur.rowcount == 0:
					return jsonify({'success': False, 'message': 'Producto no encontrado'}), 404
			conn.commit()
		return jsonify({'success': True, 'message': 'Producto eliminado correctamente'})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/venta', methods=['POST'])
def save_venta():
	data = request.get_json() or {}
	nombre = data.get('nombre')
	total_venta = data.get('total_venta')
	productos = data.get('productos', [])

	if not nombre or total_venta is None:
		return jsonify({'success': False, 'message': 'Faltan campos requeridos'}), 400

	try:
		with get_connection() as conn:
			with conn.cursor() as cur:
				cur.execute("""
					INSERT INTO tmventas(nombre, total_venta)
					VALUES (%s, %s)
					RETURNING pknum_factura
				""", (nombre, total_venta))
				pknum_factura = cur.fetchone()[0]

				for p in productos:
					codigo = str(p.get('codigo'))
					cantidad = int(p.get('cantidad') or 0)
					if cantidad <= 0:
						continue

					cur.execute("SELECT restantes FROM tdnventario WHERE pkcodigo = %s FOR UPDATE", (codigo,))
					row = cur.fetchone()
					if not row:
						raise ValueError(f'Producto no encontrado: {codigo}')

					restantes = row[0] or 0
					if restantes < cantidad:
						raise ValueError(f'Stock insuficiente para {codigo}')

					cur.execute("UPDATE tdnventario SET restantes = %s WHERE pkcodigo = %s", (restantes - cantidad, codigo))
					cur.execute("INSERT INTO tdventas(fknum_factura, fkcodigo, cantidad) VALUES (%s, %s, %s)", (pknum_factura, codigo, cantidad))
			conn.commit()

		return jsonify({'success': True, 'pknum_factura': pknum_factura, 'message': 'Venta registrada correctamente'})
	except ValueError as e:
		return jsonify({'success': False, 'message': str(e)}), 400
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/notificaciones', methods=['GET'])
def get_notificaciones():
	try:
		exists = bd.fetchall("SELECT 1 FROM information_schema.tables WHERE table_name = 'tmnotificaciones' LIMIT 1")
		if not exists:
			return jsonify([])
		rows = bd.fetchall("""
			SELECT n.id_notificacion, n.mensaje, n.fecha_creacion, n.leida,
				n.fkcodigo AS producto_codigo, i.nombre AS producto_nombre, i.restantes
			FROM tmnotificaciones n
			LEFT JOIN tdnventario i ON i.pkcodigo = n.fkcodigo
			ORDER BY n.fecha_creacion DESC
			LIMIT 200
		""")
		return jsonify(rows)
	except Exception:
		return jsonify([])

@app.route('/api/notificaciones/<int:id>/marcar-leida', methods=['POST'])
def marcar_notificacion_leida(id):
	try:
		exists = bd.fetchall("SELECT 1 FROM information_schema.tables WHERE table_name = 'tmnotificaciones' LIMIT 1")
		if not exists:
			return jsonify({'success': True, 'affected': 0})
		affected = bd.execute("UPDATE tmnotificaciones SET leida = true WHERE id_notificacion = %s", (id,))
		return jsonify({'success': True, 'affected': affected})
	except Exception as e:
		return jsonify({'error': str(e)}), 500

@app.route('/api/estadisticas', methods=['GET'])
def get_estadisticas():
	try:
		products = bd.fetchall("SELECT COUNT(*) AS total FROM tdnventario")[0]['total']
		ventas_hoy = bd.fetchall("SELECT COUNT(*) AS total FROM tmventas WHERE fecha_venta = CURRENT_DATE")[0]['total']
		ingresos_mes = bd.fetchall("SELECT COALESCE(SUM(total_venta), 0) AS total FROM tmventas WHERE date_trunc('month', fecha_venta) = date_trunc('month', CURRENT_DATE)")[0]['total']
		stock_bajo = bd.fetchall("SELECT COUNT(*) AS total FROM tdnventario WHERE restantes <= 10")[0]['total']
		return jsonify({'productos': int(products), 'ventasHoy': int(ventas_hoy), 'ingresosMes': float(ingresos_mes), 'stockBajo': int(stock_bajo)})
	except Exception as e:
		return jsonify({'error': str(e)}), 500

@app.route('/api/reportes/ingresos', methods=['GET'])
def get_reportes_ingresos():
	try:
		periodo = request.args.get('periodo', 'dia')
		if periodo == 'rango':
			fecha_inicio = request.args.get('fechaInicio')
			fecha_fin = request.args.get('fechaFin')
			if not fecha_inicio or not fecha_fin:
				return jsonify({'success': False, 'message': 'Fechas de rango requeridas'}), 400
			q = "SELECT COUNT(*) AS ventas, COALESCE(SUM(total_venta),0) AS total, COALESCE(AVG(total_venta),0) AS promedio FROM tmventas WHERE fecha_venta BETWEEN %s AND %s"
			params = (fecha_inicio, fecha_fin)
		elif periodo == 'semana':
			q = "SELECT COUNT(*) AS ventas, COALESCE(SUM(total_venta),0) AS total, COALESCE(AVG(total_venta),0) AS promedio FROM tmventas WHERE fecha_venta >= CURRENT_DATE - INTERVAL '6 days'"
			params = ()
		elif periodo == 'mes':
			q = "SELECT COUNT(*) AS ventas, COALESCE(SUM(total_venta),0) AS total, COALESCE(AVG(total_venta),0) AS promedio FROM tmventas WHERE date_trunc('month', fecha_venta) = date_trunc('month', CURRENT_DATE)"
			params = ()
		else:
			q = "SELECT COUNT(*) AS ventas, COALESCE(SUM(total_venta),0) AS total, COALESCE(AVG(total_venta),0) AS promedio FROM tmventas WHERE fecha_venta = CURRENT_DATE"
			params = ()
		row = bd.fetchall(q, params)[0]
		return jsonify({
			'success': True,
			'totalVentas': int(row['ventas']),
			'promedioVenta': float(row['promedio']),
			'total': float(row['total']),
			'totalIngresos': float(row['total'])
		})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/reportes/productos-vendidos', methods=['GET'])
def get_reportes_productos_vendidos():
	try:
		ordenar = request.args.get('ordenar', 'cantidad')
		top = int(request.args.get('top', 10))
		order_clause = 'SUM(d.cantidad) DESC' if ordenar == 'cantidad' else 'SUM(d.cantidad * i.precio_unitario) DESC'
		q = f"""
			SELECT d.fkcodigo AS codigo,
				i.nombre,
				i.categoria,
				SUM(d.cantidad)::integer AS cantidad_vendida,
				COALESCE(SUM(d.cantidad * i.precio_unitario),0)::numeric AS valor_total
			FROM tdventas d
			JOIN tdnventario i ON i.pkcodigo = d.fkcodigo
			GROUP BY d.fkcodigo, i.nombre, i.categoria
			ORDER BY {order_clause}
			LIMIT %s
		"""
		rows = bd.fetchall(q, (top,))
		productos = [{'codigo': r['codigo'], 'nombre': r['nombre'], 'categoria': r['categoria'], 'cantidadVendida': int(r['cantidad_vendida']), 'valorTotal': float(r['valor_total'])} for r in rows]
		return jsonify({'success': True, 'productos': productos})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/reportes/stock-bajo', methods=['GET'])
def get_reportes_stock_bajo():
	try:
		rows = bd.fetchall("SELECT pkcodigo AS codigo, nombre, categoria, restantes::integer AS cantidad_actual FROM tdnventario WHERE restantes <= 10 ORDER BY restantes ASC")
		productos = [{'codigo': r['codigo'], 'nombre': r['nombre'], 'categoria': r['categoria'], 'cantidad_actual': int(r['cantidad_actual'] or 0)} for r in rows]
		return jsonify({'success': True, 'productos': productos})
	except Exception as e:
		return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
	port = int(os.getenv('PORT', 3000))
	# Ejecutar con: python server.py
	app.run(host='0.0.0.0', port=port, debug=True)
