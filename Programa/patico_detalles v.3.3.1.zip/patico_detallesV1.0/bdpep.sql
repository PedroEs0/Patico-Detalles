--   	\i C:/Users/EDWARD/Desktop/Tarea/Ingenieria/Programa/patico_detallesV1.0/bdpep.sql
--      \i C:/Users/Paula/OneDrive/Escritorio/patico_detalles/bdpep.sql
-- Si falta un disparador meter lo de fecha actualizacion en la ventana de reabastecer

\c postgres
drop database bdpep;
create database bdpep;
\c bdpep

-- 1. TABLAS DE CATÁLOGO Y MAESTRAS
--------------------------------------------------------

-- Estados 
CREATE TABLE tmstatus (
    pkid        INTEGER     NOT NULL PRIMARY KEY,
    descripcion TEXT        NOT NULL
);

-- Catálogo de productos 
CREATE TABLE tdnventario (
    pkcodigo          TEXT           NOT NULL PRIMARY KEY,
    categoria         TEXT           NOT NULL,
    nombre            TEXT           NOT NULL,
    fecha_vencimiento TEXT           NOT NULL DEFAULT 'No aplica',
    notas             TEXT           NOT NULL,
    precio_unitario   NUMERIC(15,2)  NOT NULL,
    restantes         NUMERIC(5)     NOT NULL,         
    fkid              INTEGER        NOT NULL DEFAULT 1,
    FOREIGN KEY (fkid) REFERENCES tmstatus(pkid)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Tabla de reabastecimientos 
CREATE TABLE tmreabastecer (
    num                SERIAL    NOT NULL PRIMARY KEY,
    fkcodigo           TEXT      NOT NULL,          
    fecha_adquisicion  TEXT,
    comprobado_por     TEXT,
    proveedor          TEXT,
    cantidad           NUMERIC(5)     NOT NULL,             
    costo_total        NUMERIC(15,2)  NOT NULL,             
    fkid               INTEGER   NOT NULL,
    FOREIGN KEY (fkid) REFERENCES tmstatus(pkid)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (fkcodigo) REFERENCES tdnventario(pkcodigo)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Ventas (facturas) 
CREATE TABLE tmventas (
    pknum_factura SERIAL PRIMARY KEY,
    nombre        TEXT           NOT NULL,
    fecha_venta   DATE           NOT NULL DEFAULT CURRENT_DATE,
    total_venta   NUMERIC(20)    NOT NULL,
    fkid          INTEGER        NOT NULL DEFAULT 1,
    FOREIGN KEY (fkid) REFERENCES tmstatus(pkid)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Detalles de cada venta 
CREATE TABLE tdventas (
    id_detalle    SERIAL PRIMARY KEY,
    fknum_factura INTEGER    NOT NULL,
    fkcodigo      TEXT       NOT NULL,
    cantidad      NUMERIC(5) NOT NULL,
    FOREIGN KEY (fknum_factura) REFERENCES tmventas(pknum_factura),
    FOREIGN KEY (fkcodigo)     REFERENCES tdnventario(pkcodigo)
);

-- Usuarios del sistema
CREATE TABLE tmusuarios (
    pkusuario TEXT    NOT NULL PRIMARY KEY,
    contra    TEXT    NOT NULL,
    cargo     TEXT    NOT NULL,
    fkid      INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (fkid) REFERENCES tmstatus(pkid)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 2. INSERCIÓN DE DATOS INICIALES
--------------------------------------------------------

INSERT INTO tmstatus (pkid, descripcion) VALUES
    (0, 'Inactivo'),
    (1, 'Activo');

INSERT INTO tmusuarios (pkusuario, contra, cargo) VALUES
    ('admin', 'ad123', 'Administrador');
