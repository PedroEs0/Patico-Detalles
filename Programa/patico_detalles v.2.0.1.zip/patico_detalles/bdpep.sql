--   	\i C:/Users/EDWARD/OneDrive/Escritorio/Tarea/BD2/Proyecto/bdpep.sql
-- Si falta un disparador meter lo de fecha actualizacion en la ventana de reabastecer

\c postgres
drop database bdpep;
create database bdpep;
\c bdpep

--Creacion de las tablas

create table tmstatus(
pkid integer not null primary key,
descripcion text not null);

--Insertar datos de status
insert into tmstatus(pkid,descripcion) values
(0,'Inactivo'),
(1,'Activo');

create table tmreabastecer(
pkcodigo text not null primary key,
categoria text not null,
nombre text not null,
foto bytea, -- Removido el NOT NULL para hacer la foto opcional
fecha_adquisicion text not null,
fecha_vencimiento text not null default 'No aplica',
notas text not null,
comprobado_por text not null,
proveedor text not null,
precio_unitario numeric(15,2) not null,
cantidad numeric(5) not null,
costo_total numeric(15,2) not null,
fkid integer not null default 1,
foreign key(fkid) references tmstatus(pkid) on update cascade on delete restrict);

create table tdinventario(
fkcodigo numeric(10) not null primary key,
restantes numeric(5) not null,
fkid integer not null,
foreign key(fkid) references tmstatus(pkid) on update cascade on delete restrict,
foreign key(fkcodigo) references tmreabastecer(pkcodigo) on update cascade on delete restrict);

create table tmventas(
num_factura SERIAL PRIMARY KEY,
nombre TEXT NOT NULL,
fecha_venta date NOT NULL DEFAULT CURRENT_DATE,
archivo BYTEA NOT NULL,
total_venta Numeric(20) not null,
fkid integer not null default 1,
foreign key(fkid) references tmstatus(pkid) on update cascade on delete restrict);

create table tmusuarios(
pkusuario text not null primary key,
contra text not null,
cargo text not null,
fkid integer not null default 1,
foreign key(fkid) references tmstatus(pkid) on update cascade on delete restrict);

-- Crear tabla para notificaciones
CREATE TABLE tmnotificaciones (
    id_notificacion SERIAL PRIMARY KEY,
    fkcodigo numeric(10) NOT NULL,
    mensaje TEXT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    leida BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (fkcodigo) REFERENCES tmreabastecer(pkcodigo)
);

-- Crear tabla permanente de detalles de venta en lugar de temporal
CREATE TABLE tdventas (
    id_detalle SERIAL,
    fknum_factura SERIAL,
    fkcodigo text,
    cantidad numeric(5),
    FOREIGN KEY (fknum_factura) REFERENCES tmventas(num_factura),
    FOREIGN KEY (fkcodigo) REFERENCES tmreabastecer(pkcodigo)
);

-- Eliminar triggers y funciones existentes
DROP TRIGGER IF EXISTS tr_actualizar_inventario ON tmventas;
DROP TRIGGER IF EXISTS tr_stock_bajo ON tdinventario;
DROP FUNCTION IF EXISTS fn_actualizar_inventario();

-- Función para actualizar inventario (simplificada y corregida)
CREATE OR REPLACE FUNCTION fn_actualizar_inventario()
RETURNS TRIGGER AS $$
BEGIN
    -- Reducir inventario basado en los detalles de venta
    WITH detalles_venta AS (
        SELECT fkcodigo, SUM(cantidad) as total_vendido
        FROM tdventas
        WHERE fknum_factura = NEW.num_factura
        GROUP BY fkcodigo
    )
    UPDATE tdinventario i
    SET restantes = GREATEST(0, i.restantes - dv.total_vendido)
    FROM detalles_venta dv
    WHERE i.fkcodigo = dv.fkcodigo;

    -- Generar notificaciones para productos con stock bajo
    INSERT INTO tmnotificaciones(fkcodigo, mensaje)
    SELECT 
        i.fkcodigo,
        'ALERTA: Quedan ' || i.restantes || ' unidades de ' || r.nombre
    FROM tdinventario i
    JOIN tmreabastecer r ON r.pkcodigo = i.fkcodigo
    WHERE i.restantes < 10;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Crear trigger de actualización de inventario
CREATE TRIGGER tr_actualizar_inventario
AFTER INSERT ON tmventas
FOR EACH ROW
EXECUTE FUNCTION fn_actualizar_inventario();

--Insertar datos de usuarios

insert into tmusuarios(pkusuario,contra,cargo) values
('admin','postgres','Administrador');


















