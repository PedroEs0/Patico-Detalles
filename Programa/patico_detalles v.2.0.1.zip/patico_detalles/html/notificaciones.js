class NotificacionesWidget {
    constructor() {
        this.container = null;
        this.notificaciones = [];
        this.init();
    }

    async init() {
        this.createContainer();
        await this.loadNotificaciones();
        setInterval(() => this.loadNotificaciones(), 30000); // Actualizar cada 30s
    }

    createContainer() {
        // Crear contenedor flotante
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="notificaciones-widget" style="
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 300px;
                max-height: 400px;
                overflow-y: auto;
                background: white;
                border-radius: 15px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                z-index: 1000;
                padding: 15px;
                display: none;
            ">
                <div class="header" style="
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 10px;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #f0e6e8;
                ">
                    <h5 style="margin: 0; color: #513535;">Notificaciones</h5>
                    <span class="badge" style="
                        background: #d4a5a5;
                        color: white;
                        padding: 3px 8px;
                        border-radius: 10px;
                        font-size: 12px;
                    ">0</span>
                </div>
                <div class="notificaciones-list"></div>
            </div>
        `;
        document.body.appendChild(div);
        this.container = div.querySelector('.notificaciones-widget');
    }

    async loadNotificaciones() {
        try {
            const res = await fetch('http://localhost:3000/api/notificaciones');
            if (!res.ok) throw new Error('Error cargando notificaciones');
            this.notificaciones = await res.json();
            this.render();
        } catch (err) {
            console.error('Error cargando notificaciones:', err);
        }
    }

    render() {
        const list = this.container.querySelector('.notificaciones-list');
        const badge = this.container.querySelector('.badge');
        
        if (this.notificaciones.length === 0) {
            list.innerHTML = '<p style="text-align: center; color: #8b6b6b;">No hay notificaciones</p>';
            badge.style.display = 'none';
            return;
        }

        badge.style.display = 'block';
        badge.textContent = this.notificaciones.length;
        this.container.style.display = 'block';

        list.innerHTML = this.notificaciones.map(n => `
            <div class="notificacion" style="
                padding: 10px;
                border-bottom: 1px solid #f0e6e8;
                cursor: pointer;
            " onclick="notificacionesWidget.marcarLeida(${n.id_notificacion})">
                <p style="margin: 0 0 5px; color: #513535;">${n.mensaje}</p>
                <small style="color: #8b6b6b;">
                    ${new Date(n.fecha_creacion).toLocaleString()}
                </small>
            </div>
        `).join('');
    }

    async marcarLeida(id) {
        try {
            const res = await fetch(`http://localhost:3000/api/notificaciones/${id}/marcar-leida`, {
                method: 'POST'
            });
            if (!res.ok) throw new Error('Error al marcar como leída');
            await this.loadNotificaciones();
        } catch (err) {
            console.error('Error:', err);
        }
    }
}

// Inicializar widget al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
    window.notificacionesWidget = new NotificacionesWidget();
});
